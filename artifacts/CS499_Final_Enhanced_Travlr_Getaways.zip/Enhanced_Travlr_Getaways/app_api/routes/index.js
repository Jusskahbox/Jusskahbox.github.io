const express = require('express');
const router = express.Router();

const tripsController = require('../controllers/trips');
const authController = require('../controllers/authentication');
const authenticateToken = require('../middleware/auth');

router.post('/register', authController.register);
router.post('/login', authController.login);

router
  .route('/trips')
  .get(tripsController.tripsList)
  .post(authenticateToken, tripsController.tripsAddTrip);

router
  .route('/trips/:tripCode')
  .get(tripsController.tripsFindByCode)
  .put(authenticateToken, tripsController.tripsUpdateTrip)
  .delete(authenticateToken, tripsController.tripsDeleteTrip);

module.exports = router;