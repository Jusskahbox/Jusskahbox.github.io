const mongoose = require('mongoose');
const User = mongoose.model('users');

const register = async (req, res) => {
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({
      message: 'All fields are required'
    });
  }

  try {
    const existingUser = await User.findOne({ email });

    if (existingUser) {
      return res.status(409).json({
        message: 'Email is already registered'
      });
    }

    const user = new User({
      name,
      email,
      passwordHash: ''
    });

    await user.setPassword(password);
    await user.save();

    const token = user.generateJwt();

    return res.status(200).json({ token });
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      message: 'Error registering user'
    });
  }
};

const login = async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({
      message: 'All fields are required'
    });
  }

  try {
    const user = await User.findOne({ email });

    if (!user) {
      return res.status(401).json({
        message: 'Invalid email or password'
      });
    }

    const valid = await user.validPassword(password);

    if (!valid) {
      return res.status(401).json({
        message: 'Invalid email or password'
      });
    }

    const token = user.generateJwt();

    return res.status(200).json({ token });
  } catch (err) {
    console.error(err);
    return res.status(500).json({
      message: 'Error logging in'
    });
  }
};

module.exports = {
  register,
  login
};