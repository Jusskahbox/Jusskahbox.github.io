const Trip = require('../models/travlr');

const tripFields = [
  'code',
  'name',
  'length',
  'start',
  'resort',
  'perPerson',
  'image',
  'description'
];

const buildTripPayload = (body = {}) => tripFields.reduce((payload, field) => {
  if (body[field] !== undefined) {
    payload[field] = typeof body[field] === 'string'
      ? body[field].trim()
      : body[field];
  }
  return payload;
}, {});

const validateTripPayload = (payload) => {
  const missingFields = tripFields.filter((field) => {
    const value = payload[field];
    return value === undefined || value === null || value === '';
  });

  if (missingFields.length > 0) {
    return `Missing required fields: ${missingFields.join(', ')}.`;
  }

  if (Number.isNaN(Date.parse(payload.start))) {
    return 'Start must be a valid date.';
  }

  return null;
};

const sendServerError = (res, message, err) => {
  console.error(message, err);
  return res.status(500).json({ message });
};

const tripsList = async (req, res) => {
  try {
    const filter = {};
    const resort = req.query.resort?.trim();
    const search = req.query.search?.trim();

    if (resort) {
      filter.resort = { $regex: resort, $options: 'i' };
    }

    if (search) {
      const escapedSearch = search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      filter.$or = [
        { code: { $regex: escapedSearch, $options: 'i' } },
        { name: { $regex: escapedSearch, $options: 'i' } },
        { resort: { $regex: escapedSearch, $options: 'i' } }
      ];
    }

    const usesEnhancedQuery = ['resort', 'search', 'sortBy', 'order', 'page', 'limit']
      .some((parameter) => req.query[parameter] !== undefined);

    // Preserve the original full-array behavior for existing Angular clients.
    if (!usesEnhancedQuery) {
      const trips = await Trip.find({}).lean();
      return res.status(200).json(trips);
    }

    const allowedSortFields = new Set(['code', 'name', 'start', 'resort']);
    const sortBy = allowedSortFields.has(req.query.sortBy) ? req.query.sortBy : 'start';
    const sortOrder = req.query.order === 'desc' ? -1 : 1;

    const requestedPage = Number.parseInt(req.query.page, 10);
    const requestedLimit = Number.parseInt(req.query.limit, 10);
    const page = Number.isInteger(requestedPage) && requestedPage > 0 ? requestedPage : 1;
    const limit = Number.isInteger(requestedLimit) && requestedLimit > 0
      ? Math.min(requestedLimit, 100)
      : 20;
    const skip = (page - 1) * limit;

    const [trips, total] = await Promise.all([
      Trip.find(filter)
        .sort({ [sortBy]: sortOrder, _id: 1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      Trip.countDocuments(filter)
    ]);

    return res.status(200).json({
      data: trips,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (err) {
    return sendServerError(res, 'Unable to retrieve trips.', err);
  }
};

const tripsFindByCode = async (req, res) => {
  const tripCode = req.params.tripCode?.trim();

  if (!tripCode) {
    return res.status(400).json({ message: 'Trip code is required.' });
  }

  try {
    const trip = await Trip.findOne({ code: tripCode });

    if (!trip) {
      return res.status(404).json({
        message: `Trip with code ${tripCode} was not found.`
      });
    }

    return res.status(200).json(trip);
  } catch (err) {
    return sendServerError(res, 'Unable to retrieve the requested trip.', err);
  }
};

const tripsAddTrip = async (req, res) => {
  const payload = buildTripPayload(req.body);
  const validationError = validateTripPayload(payload);

  if (validationError) {
    return res.status(400).json({ message: validationError });
  }

  try {
    const existingTrip = await Trip.findOne({ code: payload.code });
    if (existingTrip) {
      return res.status(409).json({
        message: `A trip with code ${payload.code} already exists.`
      });
    }

    const trip = await Trip.create(payload);
    return res.status(201).json(trip);
  } catch (err) {
    if (err.code === 11000) {
      return res.status(409).json({ message: 'Trip code must be unique.' });
    }
    if (err.name === 'ValidationError') {
      return res.status(400).json({ message: err.message });
    }
    return sendServerError(res, 'Unable to create trip.', err);
  }
};

const tripsUpdateTrip = async (req, res) => {
  const tripCode = req.params.tripCode?.trim();
  const payload = buildTripPayload(req.body);
  const validationError = validateTripPayload(payload);

  if (!tripCode) {
    return res.status(400).json({ message: 'Trip code is required.' });
  }

  if (validationError) {
    return res.status(400).json({ message: validationError });
  }

  try {
    if (payload.code !== tripCode) {
      const duplicate = await Trip.findOne({ code: payload.code });
      if (duplicate) {
        return res.status(409).json({
          message: `A trip with code ${payload.code} already exists.`
        });
      }
    }

    const trip = await Trip.findOneAndUpdate(
      { code: tripCode },
      payload,
      { new: true, runValidators: true }
    );

    if (!trip) {
      return res.status(404).json({
        message: `Trip with code ${tripCode} was not found.`
      });
    }

    return res.status(200).json(trip);
  } catch (err) {
    if (err.code === 11000) {
      return res.status(409).json({ message: 'Trip code must be unique.' });
    }
    if (err.name === 'ValidationError') {
      return res.status(400).json({ message: err.message });
    }
    return sendServerError(res, 'Unable to update trip.', err);
  }
};

const tripsDeleteTrip = async (req, res) => {
  const tripCode = req.params.tripCode?.trim();

  if (!tripCode) {
    return res.status(400).json({ message: 'Trip code is required.' });
  }

  try {
    const trip = await Trip.findOneAndDelete({ code: tripCode });

    if (!trip) {
      return res.status(404).json({
        message: `Trip with code ${tripCode} was not found.`
      });
    }

    return res.status(204).send();
  } catch (err) {
    return sendServerError(res, 'Unable to delete trip.', err);
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};
