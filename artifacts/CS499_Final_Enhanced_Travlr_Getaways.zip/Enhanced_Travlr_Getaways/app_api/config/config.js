/**
 * Centralized application configuration.
 * Sensitive values must be supplied through environment variables rather than
 * being embedded in source code.
 */
const getRequiredEnvironmentVariable = (name) => {
  const value = process.env[name];

  if (!value || !value.trim()) {
    throw new Error(`${name} environment variable is required.`);
  }

  return value.trim();
};

const getJwtSecret = () => getRequiredEnvironmentVariable('JWT_SECRET');

const getDatabaseUri = () => {
  if (process.env.MONGODB_URI && process.env.MONGODB_URI.trim()) {
    return process.env.MONGODB_URI.trim();
  }

  const host = process.env.DB_HOST || '127.0.0.1';
  return `mongodb://${host}/travlr`;
};

module.exports = {
  getJwtSecret,
  getDatabaseUri
};
