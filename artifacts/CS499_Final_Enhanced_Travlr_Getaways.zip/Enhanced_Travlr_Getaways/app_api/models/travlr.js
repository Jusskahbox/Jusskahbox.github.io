const mongoose = require('mongoose');

const tripSchema = new mongoose.Schema({
  code: {
    type: String,
    required: [true, 'Trip code is required.'],
    unique: true,
    trim: true,
    uppercase: true,
    minlength: [3, 'Trip code must contain at least 3 characters.'],
    maxlength: [20, 'Trip code cannot exceed 20 characters.']
  },
  name: {
    type: String,
    required: [true, 'Trip name is required.'],
    trim: true,
    minlength: [2, 'Trip name must contain at least 2 characters.'],
    maxlength: [100, 'Trip name cannot exceed 100 characters.']
  },
  length: { type: String, required: [true, 'Trip length is required.'], trim: true },
  start: { type: Date, required: [true, 'Trip start date is required.'] },
  resort: {
    type: String,
    required: [true, 'Resort is required.'],
    trim: true,
    maxlength: [100, 'Resort cannot exceed 100 characters.']
  },
  perPerson: {
    type: String,
    required: [true, 'Per-person price is required.'],
    trim: true,
    match: [/^\$?\d+(?:\.\d{2})?$/, 'Per-person price must be a valid amount, such as $799.00.']
  },
  image: { type: String, required: [true, 'Trip image is required.'], trim: true },
  description: {
    type: String,
    required: [true, 'Trip description is required.'],
    trim: true,
    minlength: [10, 'Trip description must contain at least 10 characters.'],
    maxlength: [2000, 'Trip description cannot exceed 2000 characters.']
  }
}, {
  timestamps: true
});

// Database-focused indexes support common API access patterns.
tripSchema.index({ resort: 1, start: 1 });
tripSchema.index({ start: 1, name: 1 });

const Trip = mongoose.model('trips', tripSchema);

module.exports = Trip;
