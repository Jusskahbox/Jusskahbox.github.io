# CS 499 Enhancement Three: Databases

## Artifact
Travlr Getaways MEAN full-stack application

## Database Enhancements

1. **Stronger Mongoose schema validation**
   - Added field-specific validation messages.
   - Added minimum/maximum lengths for key text fields.
   - Normalized trip codes to uppercase.
   - Added currency-format validation for `perPerson`.
   - Added Mongoose timestamps for creation/update auditing.

2. **Database indexing**
   - Retained the unique index on trip code.
   - Added a compound `{ resort: 1, start: 1 }` index for resort/date access patterns.
   - Added a `{ start: 1, name: 1 }` index to support ordered trip retrieval.

3. **Database-side query processing**
   - `GET /api/trips` preserves the original array response for the existing Angular client.
   - Optional query parameters enable `resort` and `search` filtering with pagination metadata.
   - Sorting is performed by MongoDB using an allow-list of fields (`code`, `name`, `start`, `resort`).
   - Pagination uses `skip()` and `limit()` with a maximum page size of 100.
   - `countDocuments()` returns pagination metadata.
   - `lean()` is used for read-only list results to avoid unnecessary Mongoose document overhead.

4. **Data integrity and database error handling**
   - MongoDB duplicate-key error `11000` is explicitly translated to HTTP 409 Conflict.
   - Existing Mongoose validation errors continue to return HTTP 400.
   - Existing authenticated create/update/delete routes remain unchanged.

## Example Requests

- `GET /api/trips`
- `GET /api/trips?resort=Blue%20Lagoon`
- `GET /api/trips?search=reef`
- `GET /api/trips?sortBy=name&order=asc`
- `GET /api/trips?page=1&limit=10&sortBy=start&order=desc`

## Database Design Rationale
Milestone Three demonstrated application-side data structures and algorithms. This enhancement intentionally moves persistent-data filtering, sorting, and pagination into MongoDB/Mongoose. The change demonstrates an architectural trade-off: application-side algorithms are useful for in-memory data, while database-side operations reduce unnecessary data transfer and are better suited to larger persistent datasets.
