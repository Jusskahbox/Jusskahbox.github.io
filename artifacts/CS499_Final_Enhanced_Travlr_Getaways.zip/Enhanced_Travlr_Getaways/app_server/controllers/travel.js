/* GET Travel page */

const travel = async (req, res, next) => {
    try {
        const apiUrl = `${req.protocol}://${req.get('host')}/api/trips`;

        const response = await fetch(apiUrl);

        if (!response.ok) {
            throw new Error(
                `API request failed with status ${response.status}`
            );
        }

        const trips = await response.json();

        res.render('travel', {
            title: 'Travlr Getaways',
            trips
        });
    } catch (err) {
        console.error('Error retrieving trips from API:', err);
        next(err);
    }
};

module.exports = {
    travel
};