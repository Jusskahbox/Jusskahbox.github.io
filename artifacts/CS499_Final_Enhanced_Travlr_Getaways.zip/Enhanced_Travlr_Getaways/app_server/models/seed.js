// Bring in the database connection and the Trip schema.
const mongoose = require('./db');
const Trip = require('./travlr');
const fs = require('fs');
const path = require('path');

// Read seed data from the JSON file.
const tripsPath = path.join(__dirname, '../../data/trips.json');
const trips = JSON.parse(fs.readFileSync(tripsPath, 'utf8'));

// Delete existing records, then insert the seed data.
const seedDB = async () => {
  await Trip.deleteMany({});
  await Trip.insertMany(trips);
};

// Wait for MongoDB to connect before seeding, then close the connection.
mongoose.connection.once('connected', async () => {
  try {
    await seedDB();
    console.log(`${trips.length} trip records inserted successfully.`);
  } catch (err) {
    console.error('Database seed error:', err);
    process.exitCode = 1;
  } finally {
    await mongoose.connection.close();
  }
});
