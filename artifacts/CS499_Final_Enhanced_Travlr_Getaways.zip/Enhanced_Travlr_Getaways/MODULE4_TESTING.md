# Module Four Testing Steps

1. Start the local MongoDB service.
2. From the `CS465-fullstack` project directory, run `npm install` to install Mongoose.
3. Run `npm run seed`.
4. Confirm the terminal reports that three trip records were inserted.
5. Open MongoDB Compass or DBeaver and connect to `mongodb://127.0.0.1:27017`.
6. Open the `travlr` database and the `trips` collection.
7. Verify that the collection contains three documents and that each includes `code`, `name`, `length`, `start`, `resort`, `perPerson`, `image`, and `description`.
8. Run `npm start` and confirm the terminal reports `Mongoose connected to mongodb://127.0.0.1/travlr`.

For the assignment submission, capture a screenshot of the `travlr.trips` collection in MongoDB Compass or DBeaver showing the three loaded documents.
