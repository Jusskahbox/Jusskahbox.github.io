# CS 499 Milestone Three — Algorithms and Data Structures Enhancement

## Artifact
Travlr Getaways, continuing from the Milestone Two enhanced version.

## Enhancement summary
The Angular administrator trip list was enhanced with explicit search, indexed filtering, and stable merge-sort functionality.

### Data structures
- `Trip[]` remains the ordered collection returned by the REST API.
- `Map<string, Trip[]>` indexes trips by normalized resort name. Building the index requires O(n) time and O(n) auxiliary space. After construction, selecting a resort bucket is O(1) average map lookup plus the cost of processing the matching bucket.
- `Set<string>` is used to derive unique resort names for the filter control.

### Algorithms
1. **Linear search** checks trip code, name, resort, and description. Complexity is O(n) with O(k) output space for k matches.
2. **Indexed filtering** uses the resort Map rather than rescanning the full collection for every resort selection.
3. **Stable merge sort** orders results by name, resort, start date, numeric price, or numeric trip length. Complexity is O(n log n) time and O(n) auxiliary space. Stability preserves the relative order of equal keys.
4. The operations are composed as filter -> search -> sort so later work operates on the smallest relevant collection.

## Edge cases handled
- Empty search terms return the current source collection.
- No matching resort bucket returns an empty collection.
- No search matches display a clear empty-state message.
- Price and length strings are normalized to numeric values before comparison.
- Date sorting converts values to timestamps.
- Reset restores the complete collection and default sort order.

## Design trade-offs
For a small dataset, repeatedly using `Array.filter()` and native `Array.sort()` would be shorter. The explicit index and merge-sort implementation were selected for the capstone enhancement because they make the data-structure and algorithm decisions visible, analyzable, and reusable. The Map adds O(n) memory cost in exchange for average O(1) resort-bucket retrieval. Merge sort adds O(n) auxiliary memory in exchange for predictable O(n log n) performance and stable ordering.
