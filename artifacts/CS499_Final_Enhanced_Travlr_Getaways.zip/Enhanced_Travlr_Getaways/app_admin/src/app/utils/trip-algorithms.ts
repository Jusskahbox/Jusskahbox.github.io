import { Trip } from '../models/trip';

export type TripSortField = 'name' | 'resort' | 'start' | 'price' | 'length';
export type SortDirection = 'asc' | 'desc';

/**
 * Builds an index from normalized resort name to trips.
 * Construction is O(n) time and O(n) auxiliary space.
 * A Map is used so repeated resort filtering can avoid rescanning all trips.
 */
export function buildResortIndex(trips: Trip[]): Map<string, Trip[]> {
  const index = new Map<string, Trip[]>();
  for (const trip of trips) {
    const key = normalize(trip.resort);
    const bucket = index.get(key) ?? [];
    bucket.push(trip);
    index.set(key, bucket);
  }
  return index;
}

/**
 * Case-insensitive linear search across fields useful to an administrator.
 * O(n) time for n trips and O(k) result space for k matches.
 */
export function searchTrips(trips: Trip[], query: string): Trip[] {
  const term = normalize(query);
  if (!term) return [...trips];

  return trips.filter((trip) =>
    [trip.code, trip.name, trip.resort, trip.description]
      .some((value) => normalize(value).includes(term))
  );
}

/**
 * Stable merge sort. O(n log n) time and O(n) auxiliary space.
 * Implemented explicitly rather than relying on Array.sort so the artifact
 * demonstrates the selected comparison algorithm and its trade-offs.
 */
export function mergeSortTrips(
  trips: Trip[],
  field: TripSortField,
  direction: SortDirection = 'asc'
): Trip[] {
  if (trips.length <= 1) return [...trips];

  const midpoint = Math.floor(trips.length / 2);
  const left = mergeSortTrips(trips.slice(0, midpoint), field, direction);
  const right = mergeSortTrips(trips.slice(midpoint), field, direction);
  return merge(left, right, field, direction);
}

function merge(
  left: Trip[],
  right: Trip[],
  field: TripSortField,
  direction: SortDirection
): Trip[] {
  const merged: Trip[] = [];
  let i = 0;
  let j = 0;

  while (i < left.length && j < right.length) {
    const comparison = compareTrips(left[i], right[j], field);
    const takeLeft = direction === 'asc' ? comparison <= 0 : comparison >= 0;
    merged.push(takeLeft ? left[i++] : right[j++]);
  }

  return merged.concat(left.slice(i), right.slice(j));
}

function compareTrips(a: Trip, b: Trip, field: TripSortField): number {
  switch (field) {
    case 'start':
      return new Date(a.start).getTime() - new Date(b.start).getTime();
    case 'price':
      return numericValue(a.perPerson) - numericValue(b.perPerson);
    case 'length':
      return numericValue(a.length) - numericValue(b.length);
    case 'resort':
      return normalize(a.resort).localeCompare(normalize(b.resort));
    case 'name':
    default:
      return normalize(a.name).localeCompare(normalize(b.name));
  }
}

function numericValue(value: string | number | null | undefined): number {
  const parsed = Number(String(value ?? '').replace(/[^0-9.-]/g, ''));
  return Number.isFinite(parsed) ? parsed : 0;
}

function normalize(value: unknown): string {
  return String(value ?? '').trim().toLowerCase();
}
