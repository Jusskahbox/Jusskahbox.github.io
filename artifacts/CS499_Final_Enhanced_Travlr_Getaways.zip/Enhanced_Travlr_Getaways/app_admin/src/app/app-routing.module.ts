import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { TripList } from './trip-list/trip-list';
import { AddTrip } from './add-trip/add-trip';
import { EditTrip } from './edit-trip/edit-trip';
import { LoginComponent } from './login/login.component';
import { AuthGuard } from './services/auth-guard';

const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: '',
    component: TripList,
    canActivate: [AuthGuard]
  },
  {
    path: 'add-trip',
    component: AddTrip,
    canActivate: [AuthGuard]
  },
  {
    path: 'edit-trip/:tripCode',
    component: EditTrip,
    canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
