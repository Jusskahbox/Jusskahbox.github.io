import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { Trip } from '../models/trip';
import { Authentication } from './authentication';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class TripData {
  private readonly apiBaseUrl = environment.apiBaseUrl;

  constructor(
    private http: HttpClient,
    private authenticationService: Authentication
  ) {}

  private getAuthHeaders(): HttpHeaders | null {
    const token = this.authenticationService.getToken();
    return token ? new HttpHeaders({ Authorization: `Bearer ${token}` }) : null;
  }

  private requireAuthHeaders(): HttpHeaders {
    const headers = this.getAuthHeaders();
    if (!headers) throw new Error('Authentication is required for this operation.');
    return headers;
  }

  getTrips(): Observable<Trip[]> {
    return this.http.get<Trip[]>(`${this.apiBaseUrl}/trips`);
  }

  getTrip(tripCode: string): Observable<Trip> {
    return this.http.get<Trip>(`${this.apiBaseUrl}/trips/${encodeURIComponent(tripCode)}`);
  }

  addTrip(trip: Trip): Observable<Trip> {
    try {
      return this.http.post<Trip>(`${this.apiBaseUrl}/trips`, trip, {
        headers: this.requireAuthHeaders()
      });
    } catch (error) {
      return throwError(() => error);
    }
  }

  updateTrip(originalTripCode: string, trip: Trip): Observable<Trip> {
    try {
      return this.http.put<Trip>(
        `${this.apiBaseUrl}/trips/${encodeURIComponent(originalTripCode)}`,
        trip,
        { headers: this.requireAuthHeaders() }
      );
    } catch (error) {
      return throwError(() => error);
    }
  }

  deleteTrip(tripCode: string): Observable<unknown> {
    try {
      return this.http.delete(
        `${this.apiBaseUrl}/trips/${encodeURIComponent(tripCode)}`,
        { headers: this.requireAuthHeaders() }
      );
    } catch (error) {
      return throwError(() => error);
    }
  }
}
