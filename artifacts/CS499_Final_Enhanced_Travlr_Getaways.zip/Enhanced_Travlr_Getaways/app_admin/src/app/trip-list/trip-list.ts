import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';
import {
  buildResortIndex,
  mergeSortTrips,
  searchTrips,
  SortDirection,
  TripSortField
} from '../utils/trip-algorithms';

@Component({
  selector: 'app-trip-list',
  standalone: false,
  templateUrl: './trip-list.html',
  styleUrl: './trip-list.css',
})
export class TripList implements OnInit {
  trips: Trip[] = [];
  visibleTrips: Trip[] = [];
  resorts: string[] = [];
  searchQuery = '';
  selectedResort = 'all';
  sortField: TripSortField = 'name';
  sortDirection: SortDirection = 'asc';
  errorMessage = '';

  private resortIndex = new Map<string, Trip[]>();

  constructor(
    private tripDataService: TripData,
    private changeDetectorRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.tripDataService.getTrips().subscribe({
      next: (trips: Trip[]) => {
        this.trips = trips;
        this.resortIndex = buildResortIndex(trips);
        this.resorts = Array.from(
          new Set(trips.map((trip) => trip.resort).filter(Boolean))
        ).sort((a, b) => a.localeCompare(b));
        this.applyAlgorithms();
        this.changeDetectorRef.markForCheck();
      },
      error: (error: unknown) => {
        console.error('Unable to retrieve trips:', error);
        this.errorMessage = 'Unable to retrieve trips. Please try again.';
      }
    });
  }

  applyAlgorithms(): void {
    const source = this.selectedResort === 'all'
      ? this.trips
      : (this.resortIndex.get(this.selectedResort.trim().toLowerCase()) ?? []);

    const matches = searchTrips(source, this.searchQuery);
    this.visibleTrips = mergeSortTrips(matches, this.sortField, this.sortDirection);
  }

  clearFilters(): void {
    this.searchQuery = '';
    this.selectedResort = 'all';
    this.sortField = 'name';
    this.sortDirection = 'asc';
    this.applyAlgorithms();
  }
}
