# CS 499 Enhancement One - Software Design and Engineering

This enhanced version preserves the original Travlr Getaways functionality while improving security, maintainability, validation, and error handling.

## Implemented enhancements
- Removed the hard-coded JWT secret fallback. `JWT_SECRET` is now required at runtime.
- Added centralized backend configuration for JWT and MongoDB connection settings.
- Added `.env.example` while keeping `.env` excluded from source control.
- Strengthened trip input validation and normalized incoming string values.
- Added duplicate trip-code detection and a unique schema constraint.
- Stopped returning raw internal exception details in 500-level API responses.
- Improved trip update behavior so changing a trip code does not break the route lookup.
- Removed duplicate Mongoose export code.
- Centralized the Angular API base URL in an environment configuration file.
- Improved client authentication checks by decoding JWT expiration and clearing invalid/expired tokens.
- Prevented write requests from creating `Bearer null` authorization headers.
- Added user-facing error messages for add/edit failures.

## Local setup
1. Set `JWT_SECRET` to a long random value before starting the Node application.
2. Ensure MongoDB is running locally, or set `MONGODB_URI`/`DB_HOST` as appropriate.
3. Run the Node/Express app from the project root.
4. Run the Angular administrator app from `app_admin`.
