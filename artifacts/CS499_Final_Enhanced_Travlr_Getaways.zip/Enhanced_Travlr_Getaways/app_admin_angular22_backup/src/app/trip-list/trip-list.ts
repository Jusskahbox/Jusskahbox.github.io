import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';

@Component({
  selector: 'app-trip-list',
  standalone: false,
  templateUrl: './trip-list.html',
  styleUrl: './trip-list.css',
})
export class TripList implements OnInit {
  trips: Trip[] = [];

  constructor(
    private tripDataService: TripData,
    private changeDetectorRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.tripDataService.getTrips().subscribe({
      next: (trips: Trip[]) => {
        console.log('Trips received:', trips);
        this.trips = trips;
        this.changeDetectorRef.markForCheck();
      },
      error: (error: unknown) => {
        console.error('Unable to retrieve trips:', error);
      }
    });
  }
}
