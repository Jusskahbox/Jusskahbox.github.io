import { NgModule, provideBrowserGlobalErrorListeners } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing-module';
import { App } from './app';
import { TripList } from './trip-list/trip-list';
import { TripCard } from './trip-card/trip-card';
import { EditTrip } from './edit-trip/edit-trip';
import { AddTrip } from './add-trip/add-trip';

@NgModule({
  declarations: [
    App,
    TripList,
    TripCard,
    EditTrip,
    AddTrip
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [provideBrowserGlobalErrorListeners()],
  bootstrap: [App],
})
export class AppModule {}
