import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';

@Component({
  selector: 'app-edit-trip',
  standalone: false,
  templateUrl: './edit-trip.html',
  styleUrl: './edit-trip.css',
})
export class EditTrip implements OnInit {
  trip?: Trip;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private tripDataService: TripData,
    private changeDetectorRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    const tripCode = this.route.snapshot.paramMap.get('tripCode');

    if (tripCode) {
      this.tripDataService.getTrip(tripCode).subscribe({
        next: (trip: Trip) => {
          this.trip = trip;
          this.changeDetectorRef.markForCheck();
        },
        error: (error: unknown) => {
          console.error('Unable to retrieve trip:', error);
        }
      });
    }
  }

  saveTrip(): void {
    if (!this.trip) {
      return;
    }

    this.tripDataService.updateTrip(this.trip).subscribe({
      next: () => {
        this.router.navigate(['/']);
      },
      error: (error: unknown) => {
        console.error('Unable to update trip:', error);
      }
    });
  }
}
