import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Trip } from '../models/trip';
import { TripData } from '../services/trip-data';

@Component({
  selector: 'app-add-trip',
  standalone: false,
  templateUrl: './add-trip.html',
  styleUrl: './add-trip.css',
})
export class AddTrip {
  trip: Trip = new Trip();
  startDate = '';

  constructor(
    private tripDataService: TripData,
    private router: Router
  ) {}

  saveTrip(): void {
    if (
      !this.trip.code ||
      !this.trip.name ||
      !this.trip.length ||
      !this.startDate ||
      !this.trip.resort ||
      !this.trip.perPerson ||
      !this.trip.image ||
      !this.trip.description
    ) {
      alert('Please complete all trip fields.');
      return;
    }

    this.trip.start = new Date(this.startDate);

    this.tripDataService.addTrip(this.trip).subscribe({
      next: () => {
        this.router.navigate(['/']);
      },
      error: (error: unknown) => {
        console.error('Unable to add trip:', error);
      }
    });
  }
}
