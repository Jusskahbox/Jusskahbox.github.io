import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';

interface AuthResponse {
  token: string;
}

@Injectable({
  providedIn: 'root'
})
export class Authentication {
  private apiBaseUrl = 'http' + '://localhost:3000/api';

  constructor(private http: HttpClient) {}

  login(email: string, password: string): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(
      `${this.apiBaseUrl}/login`,
      { email, password }
    ).pipe(
      tap((response: AuthResponse) => {
        localStorage.setItem('travlr-token', response.token);
      })
    );
  }

  logout(): void {
    localStorage.removeItem('travlr-token');
  }

  getToken(): string | null {
    return localStorage.getItem('travlr-token');
  }

  isLoggedIn(): boolean {
    return this.getToken() !== null;
  }
}


