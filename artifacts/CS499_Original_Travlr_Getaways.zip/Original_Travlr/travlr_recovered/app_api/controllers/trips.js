const Trip = require('../models/travlr');

/**
 * GET /api/trips
 * Return every trip.
 */
const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find({});
    return res.status(200).json(trips);
  } catch (err) {
    console.error('Error retrieving trips:', err);

    return res.status(500).json({
      message: 'Unable to retrieve trips.',
      error: err.message
    });
  }
};

/**
 * GET /api/trips/:tripCode
 * Return one trip identified by its code.
 */
const tripsFindByCode = async (req, res) => {
  const { tripCode } = req.params;

  if (!tripCode) {
    return res.status(400).json({
      message: 'Trip code is required.'
    });
  }

  try {
    const trip = await Trip.findOne({ code: tripCode });

    if (!trip) {
      return res.status(404).json({
        message: `Trip with code ${tripCode} was not found.`
      });
    }

    return res.status(200).json(trip);
  } catch (err) {
    console.error(`Error retrieving trip ${tripCode}:`, err);

    return res.status(500).json({
      message: 'Unable to retrieve the requested trip.',
      error: err.message
    });
  }
};

/**
 * POST /api/trips
 * Create a new trip.
 */
const tripsAddTrip = async (req, res) => {
  try {
    const trip = await Trip.create({
      code: req.body.code,
      name: req.body.name,
      length: req.body.length,
      start: req.body.start,
      resort: req.body.resort,
      perPerson: req.body.perPerson,
      image: req.body.image,
      description: req.body.description
    });

    return res.status(201).json(trip);
  } catch (err) {
    console.error('Error creating trip:', err);

    return res.status(400).json({
      message: 'Unable to create trip.',
      error: err.message
    });
  }
};

/**
 * PUT /api/trips/:tripCode
 * Update an existing trip.
 */
const tripsUpdateTrip = async (req, res) => {
  const { tripCode } = req.params;

  try {
    const trip = await Trip.findOneAndUpdate(
      { code: tripCode },
      {
        code: req.body.code,
        name: req.body.name,
        length: req.body.length,
        start: req.body.start,
        resort: req.body.resort,
        perPerson: req.body.perPerson,
        image: req.body.image,
        description: req.body.description
      },
      {
        new: true,
        runValidators: true
      }
    );

    if (!trip) {
      return res.status(404).json({
        message: `Trip with code ${tripCode} was not found.`
      });
    }

    return res.status(200).json(trip);
  } catch (err) {
    console.error(`Error updating trip ${tripCode}:`, err);

    return res.status(400).json({
      message: 'Unable to update trip.',
      error: err.message
    });
  }
};

/**
 * DELETE /api/trips/:tripCode
 * Delete an existing trip.
 */
const tripsDeleteTrip = async (req, res) => {
  const { tripCode } = req.params;

  try {
    const trip = await Trip.findOneAndDelete({ code: tripCode });

    if (!trip) {
      return res.status(404).json({
        message: `Trip with code ${tripCode} was not found.`
      });
    }

    return res.status(204).send();
  } catch (err) {
    console.error(`Error deleting trip ${tripCode}:`, err);

    return res.status(500).json({
      message: 'Unable to delete trip.',
      error: err.message
    });
  }
};

module.exports = {
  tripsList,
  tripsFindByCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};